-- Delivery model for digital assets
CREATE TYPE public.delivery_type AS ENUM ('license_key', 'file', 'service', 'external_link');

ALTER TABLE public.products
  ADD COLUMN delivery_type public.delivery_type NOT NULL DEFAULT 'file',
  ADD COLUMN delivery_instructions text,
  ADD COLUMN external_url text;

-- Inventory of access keys / software licenses
CREATE TABLE public.license_keys (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id uuid NOT NULL REFERENCES public.products(id) ON DELETE CASCADE,
  seller_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  key_value text NOT NULL,
  status text NOT NULL DEFAULT 'available',
  order_item_id uuid REFERENCES public.order_items(id) ON DELETE SET NULL,
  note text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT license_keys_status_check CHECK (status IN ('available', 'sold', 'revoked'))
);

CREATE INDEX license_keys_product_idx ON public.license_keys (product_id, status);
CREATE INDEX license_keys_seller_idx ON public.license_keys (seller_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.license_keys TO authenticated;
GRANT ALL ON public.license_keys TO service_role;

ALTER TABLE public.license_keys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Sellers manage their own license keys"
  ON public.license_keys FOR ALL TO authenticated
  USING (auth.uid() = seller_id)
  WITH CHECK (auth.uid() = seller_id);

CREATE POLICY "Buyers can view keys from their orders"
  ON public.license_keys FOR SELECT TO authenticated
  USING (EXISTS (
    SELECT 1 FROM public.order_items oi
    JOIN public.orders o ON o.id = oi.order_id
    WHERE oi.id = license_keys.order_item_id AND o.buyer_id = auth.uid()
  ));

CREATE POLICY "Admins manage license keys"
  ON public.license_keys FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER update_license_keys_updated_at
  BEFORE UPDATE ON public.license_keys
  FOR EACH ROW EXECUTE FUNCTION private.update_updated_at_column();

-- New categories for keys, licenses and services
INSERT INTO public.categories (slug, name, description, icon, sort_order) VALUES
  ('chaves-de-acesso', 'Chaves de acesso', 'Chaves e credenciais de acesso a plataformas e contas premium.', 'key-round', 10),
  ('licencas-software', 'Licenças de software', 'Licenças originais e ativações para softwares e aplicativos.', 'shield-check', 11),
  ('servicos-ads', 'Serviços de anúncios', 'Gestão e configuração de campanhas de tráfego pago.', 'megaphone', 12),
  ('ferramentas-meta', 'Ferramentas Meta', 'BMs, contas de anúncio, pixels e ferramentas do ecossistema Meta.', 'share-2', 13)
ON CONFLICT (slug) DO NOTHING;