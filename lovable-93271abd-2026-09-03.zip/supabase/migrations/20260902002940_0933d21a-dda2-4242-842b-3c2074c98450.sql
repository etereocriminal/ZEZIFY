-- has_role é usada em políticas RLS, então usuários autenticados precisam executá-la.
-- Anônimos não devem executar diretamente.
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;

-- update_updated_at_column é usada apenas por triggers; não deve ser chamada diretamente.
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM authenticated;
REVOKE EXECUTE ON FUNCTION public.update_updated_at_column() FROM anon;

-- handle_new_user é usada apenas por trigger no auth.users; não deve ser chamada diretamente.
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM authenticated;
REVOKE EXECUTE ON FUNCTION public.handle_new_user() FROM anon;
