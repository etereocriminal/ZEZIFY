# Plataforma de Marketplace de Ativos Digitais

## Visão
Criar uma plataforma estilo marketplace onde criadores podem cadastrar e vender ativos digitais (cursos, ebooks, templates, SaaS, presets, etc.) e compradores podem descobrir, comprar e acessar seus ativos. Visual escuro, moderno e premium.

## Decisões assumidas
- **Modelo**: marketplace multi-vendedor.
- **Produtos**: ativos digitais (sem envio físico).
- **Idiomas**: português como primário, estrutura pronta para inglês futuro.
- **Estilo visual**: escuro e moderno (cores profundas, acentos azul/roxo, tipografia clean).
- **Pagamento**: Stripe built-in (taxa e entrega digital automatizada), com possibilidade futura de split com vendedores.
- **Backend**: Lovable Cloud (PostgreSQL + auth) para usuários, produtos, pedidos e downloads.

## Escopo do MVP
### 1. Autenticação
- Login/cadastro com e-mail e OAuth (Google/Apple via Lovable Cloud).
- Perfis de comprador e vendedor (qualquer usuário pode se tornar vendedor).

### 2. Catálogo e descoberta
- Página inicial com hero, categorias, produtos em destaque.
- Página de listagem de produtos com filtros por categoria, preço e avaliação.
- Página de detalhes do produto com imagem, descrição, autor, preço e CTA de compra.

### 3. Área do vendedor
- Dashboard do vendedor com produtos cadastrados.
- CRUD de produtos: título, descrição, categoria, preço, arquivos (entrega digital) e imagens.

### 4. Checkout e entrega
- Checkout Stripe integrado.
- Página de "Meus downloads" após compra.

### 5. Admin básico
- Painel para aprovar produtos e gerenciar comissões.

## Estrutura de rotas proposta
- `/` — landing page
- `/explore` — catálogo
- `/products/$slug` — detalhe do produto
- `/auth` — login/cadastro
- `/dashboard` — dashboard do vendedor
- `/dashboard/products/new` — criar produto
- `/dashboard/products/$id/edit` — editar produto
- `/purchases` — meus downloads
- `/admin` — painel administrativo

## Design
- Sistema de design escuro por padrão, com tokens semânticos em oklch.
- Gradiente sutil de fundo, cards com glassmorphism leve.
- Tipografia sans-serif moderna.

## Tecnologias
- TanStack Start + React 19
- Tailwind CSS v4
- Lovable Cloud (auth + banco)
- Stripe built-in
- shadcn/ui

## Próximos passos
1. Habilitar Lovable Cloud e Stripe built-in.
2. Definir design system no `src/styles.css`.
3. Criar schema do banco (usuários, produtos, categorias, pedidos, downloads).
4. Construir landing page e catálogo.
5. Implementar auth, dashboard do vendedor, checkout e entrega.
