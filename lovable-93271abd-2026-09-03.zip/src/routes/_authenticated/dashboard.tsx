import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/_authenticated/dashboard")({
  head: () => ({
    meta: [
      { title: "Painel do vendedor — ZeziFy" },
      { name: "description", content: "Gerencie seus ativos digitais, vendas e downloads no painel ZeziFy." },
      { property: "og:title", content: "Painel do vendedor — ZeziFy" },
      { property: "og:description", content: "Gerencie seus ativos digitais, vendas e downloads no painel ZeziFy." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: DashboardPage,
});

function DashboardPage() {
  return (
    <div className="mx-auto max-w-5xl px-4 py-16">
      <h1 className="text-3xl font-bold text-foreground">Painel do vendedor</h1>
      <p className="mt-3 text-muted-foreground">
        Em breve: cadastro de produtos, vendas e relatórios.
      </p>
      <Link
        to="/explore"
        className="mt-8 inline-flex rounded-lg border border-border px-5 py-2.5 text-sm font-semibold text-foreground"
      >
        Ver catálogo
      </Link>
    </div>
  );
}
