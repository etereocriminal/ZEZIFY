import { createFileRoute, useParams } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Star, ShoppingCart, Download, Share2, User } from "lucide-react";
import { getProductBySlug } from "@/lib/products.functions";

const productQueryOptions = (slug: string) =>
  queryOptions({
    queryKey: ["product", slug],
    queryFn: () => getProductBySlug({ data: { slug } }),
  });

export const Route = createFileRoute("/products/$slug")({
  head: ({ params }) => ({
    meta: [
      { title: `${params.slug} — ZeziFy` },
      { name: "description", content: `Compre ${params.slug} no ZeziFy.` },
      { property: "og:title", content: `${params.slug} — ZeziFy` },
      { property: "og:description", content: `Compre ${params.slug} no ZeziFy.` },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context, params }) =>
    context.queryClient.ensureQueryData(productQueryOptions(params.slug)),
  component: ProductPage,
});

function ProductPage() {
  const { slug } = useParams({ from: "/products/$slug" });
  const { data: product } = useSuspenseQuery(productQueryOptions(slug));

  const formattedPrice = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: product.currency,
  }).format(product.price);

  return (
    <div className="min-h-screen px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <div className="aspect-video overflow-hidden rounded-2xl border border-border bg-muted">
              {product.cover_url ? (
                <img
                  src={product.cover_url}
                  alt={product.title}
                  className="h-full w-full object-cover"
                />
              ) : (
                <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10 text-muted-foreground">
                  Sem imagem
                </div>
              )}
            </div>

            <div className="mt-8">
              <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl">
                {product.title}
              </h1>
              <div className="mt-4 flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                {product.categories?.name && (
                  <span className="rounded-full bg-primary/10 px-3 py-1 text-primary">
                    {product.categories.name}
                  </span>
                )}
                <div className="flex items-center gap-1">
                  <Star className="h-4 w-4 fill-primary text-primary" />
                  <span className="font-medium text-foreground">{(product.rating ?? 0).toFixed(1)}</span>
                  <span>({product.review_count} avaliações)</span>
                </div>
                <span>{product.sales_count} vendas</span>
              </div>

              <div className="mt-8 space-y-4 text-foreground/90">
                {product.description ? (
                  <div className="prose prose-invert max-w-none">
                    {product.description}
                  </div>
                ) : (
                  <p className="text-muted-foreground">Nenhuma descrição detalhada fornecida.</p>
                )}
              </div>
            </div>
          </div>

          <div className="lg:col-span-5">
            <div className="sticky top-24 rounded-2xl border border-border bg-card p-6 shadow-xl shadow-black/5">
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-bold text-foreground">{formattedPrice}</span>
                <span className="text-sm text-muted-foreground">{product.currency}</span>
              </div>

              <div className="mt-6 space-y-3">
                <button
                  type="button"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-6 py-3 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition-all hover:bg-primary/90"
                >
                  <ShoppingCart className="h-5 w-5" />
                  Comprar agora
                </button>
                <button
                  type="button"
                  className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-input bg-background px-6 py-3 text-base font-semibold text-foreground transition-colors hover:bg-accent"
                >
                  <Download className="h-5 w-5" />
                  Ver demo
                </button>
              </div>

              <div className="mt-6 flex items-center justify-between border-t border-border pt-6">
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted">
                    {product.profiles?.avatar_url ? (
                      <img
                        src={product.profiles.avatar_url}
                        alt={product.profiles.display_name ?? ""}
                        className="h-full w-full rounded-full object-cover"
                      />
                    ) : (
                      <User className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground">
                      {product.profiles?.display_name ?? "Vendedor"}
                    </p>
                    {product.profiles?.is_seller && (
                      <p className="text-xs text-muted-foreground">Criador verificado</p>
                    )}
                  </div>
                </div>
                <button
                  type="button"
                  className="inline-flex h-9 w-9 items-center justify-center rounded-md border border-input text-muted-foreground transition-colors hover:text-foreground"
                >
                  <Share2 className="h-4 w-4" />
                </button>
              </div>

              <div className="mt-6 space-y-3 rounded-xl bg-muted/50 p-4 text-sm text-muted-foreground">
                <div className="flex justify-between">
                  <span>Entrega</span>
                  <span className="font-medium text-foreground">Download digital</span>
                </div>
                <div className="flex justify-between">
                  <span>Acesso</span>
                  <span className="font-medium text-foreground">Vitalício</span>
                </div>
                <div className="flex justify-between">
                  <span>Garantia</span>
                  <span className="font-medium text-foreground">7 dias</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
