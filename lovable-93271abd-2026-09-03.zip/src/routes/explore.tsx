import { createFileRoute, Link } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { Search, SlidersHorizontal } from "lucide-react";
import { useState } from "react";
import { ProductCard, type ProductCardProps } from "@/components/ProductCard";
import { CategoryPill } from "@/components/CategoryPill";
import { listCategories, listPublishedProducts } from "@/lib/products.functions";
import { cn } from "@/lib/utils";

const categoriesQueryOptions = queryOptions({
  queryKey: ["categories"],
  queryFn: () => listCategories(),
});

const makeProductsQueryOptions = (categorySlug?: string, search?: string) =>
  queryOptions({
    queryKey: ["products", categorySlug ?? "all", search ?? ""],
    queryFn: () =>
      listPublishedProducts({
        data: {
          ...(categorySlug ? { categorySlug } : {}),
          ...(search ? { search } : {}),
          limit: 24,
          offset: 0,
        },
      }),
  });

export const Route = createFileRoute("/explore")({
  head: () => ({
    meta: [
      { title: "Explorar — ZeziFy" },
      { name: "description", content: "Descubra cursos, ebooks, templates, SaaS e outros ativos digitais no ZeziFy." },
      { property: "og:title", content: "Explorar — ZeziFy" },
      { property: "og:description", content: "Descubra cursos, ebooks, templates, SaaS e outros ativos digitais no ZeziFy." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(categoriesQueryOptions),
      context.queryClient.ensureQueryData(makeProductsQueryOptions()),
    ]),
  component: ExplorePage,
});

function ExplorePage() {
  const { data: categories } = useSuspenseQuery(categoriesQueryOptions);
  const [selectedCategory, setSelectedCategory] = useState<string | undefined>(undefined);
  const [search, setSearch] = useState("");
  const { data } = useSuspenseQuery(makeProductsQueryOptions(selectedCategory, search));

  return (
    <div className="min-h-screen px-4 py-10 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-7xl">
        <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Explorar</h1>
            <p className="mt-2 text-muted-foreground">
              Encontre o próximo ativo digital para acelerar seus projetos.
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                type="text"
                placeholder="Buscar produtos..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className={cn(
                  "h-10 w-full rounded-md border border-input bg-background pl-9 pr-4 text-sm text-foreground outline-none",
                  "placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-primary/20"
                )}
              />
            </div>
            <button
              type="button"
              className="inline-flex h-10 items-center justify-center gap-2 rounded-md border border-input bg-background px-3 text-sm font-medium text-foreground hover:bg-accent"
            >
              <SlidersHorizontal className="h-4 w-4" />
              Filtros
            </button>
          </div>
        </div>

        <div className="mt-8 flex flex-wrap gap-3">
          <CategoryPill
            label="Todos"
            active={!selectedCategory}
            onClick={() => setSelectedCategory(undefined)}
          />
          {categories.map((category) => (
            <CategoryPill
              key={category.id}
              label={category.name}
              active={selectedCategory === category.slug}
              onClick={() => setSelectedCategory(category.slug)}
            />
          ))}
        </div>

        {data.products.length === 0 ? (
          <div className="mt-16 rounded-2xl border border-dashed border-border bg-card/50 p-12 text-center">
            <h3 className="text-lg font-semibold text-foreground">Nenhum produto encontrado</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Tente mudar os filtros ou busque por outro termo.
            </p>
            <Link
              to="/dashboard"
              className="mt-6 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            >
              Publicar um produto
            </Link>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {data.products.map((product: ProductCardProps) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        )}

        {data.count > data.products.length && (
          <div className="mt-12 text-center">
            <button
              type="button"
              className="inline-flex items-center justify-center rounded-md border border-input bg-background px-6 py-2.5 text-sm font-medium text-foreground transition-colors hover:bg-accent"
            >
              Carregar mais
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
