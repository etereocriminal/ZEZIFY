import { createFileRoute, Link, useLoaderData } from "@tanstack/react-router";
import { queryOptions, useSuspenseQuery } from "@tanstack/react-query";
import { ArrowRight, Zap, Shield, Globe, Headphones } from "lucide-react";
import { Hero } from "@/components/Hero";
import { ProductCard, type ProductCardProps } from "@/components/ProductCard";
import { CategoryPill } from "@/components/CategoryPill";
import { listCategories, getFeaturedProducts } from "@/lib/products.functions";

const featuredQueryOptions = queryOptions({
  queryKey: ["featured-products"],
  queryFn: () => getFeaturedProducts(),
});

const categoriesQueryOptions = queryOptions({
  queryKey: ["categories"],
  queryFn: () => listCategories(),
});

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ZeziFy — Marketplace de Ativos Digitais" },
      { name: "description", content: "Compre e venda cursos, ebooks, templates, SaaS, presets e outros ativos digitais no ZeziFy." },
      { property: "og:title", content: "ZeziFy — Marketplace de Ativos Digitais" },
      { property: "og:description", content: "Compre e venda cursos, ebooks, templates, SaaS, presets e outros ativos digitais no ZeziFy." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  loader: ({ context }) =>
    Promise.all([
      context.queryClient.ensureQueryData(categoriesQueryOptions),
      context.queryClient.ensureQueryData(featuredQueryOptions),
    ]),
  component: HomePage,
});

function HomePage() {
  const { data: categories } = useSuspenseQuery(categoriesQueryOptions);
  const { data: featured } = useSuspenseQuery(featuredQueryOptions);

  return (
    <div>
      <Hero />

      <section className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight text-foreground">Categorias em alta</h2>
          <Link to="/explore" className="hidden items-center gap-1 text-sm font-medium text-primary hover:underline sm:flex">
            Ver todas <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
        <div className="mt-6 flex flex-wrap gap-3">
          {categories.map((category) => (
            <CategoryPill key={category.id} label={category.name} />
          ))}
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 pb-16 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold tracking-tight text-foreground">Produtos em destaque</h2>
          <Link to="/explore" className="flex items-center gap-1 text-sm font-medium text-primary hover:underline">
            Explorar tudo <ArrowRight className="h-4 w-4" />
          </Link>
        </div>

        {featured.length === 0 ? (
          <div className="mt-10 rounded-2xl border border-dashed border-border bg-card/50 p-12 text-center">
            <p className="text-muted-foreground">Nenhum produto publicado ainda. Seja o primeiro a vender!</p>
            <Link
              to="/dashboard"
              className="mt-4 inline-flex items-center justify-center rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground"
            >
              Publicar produto
            </Link>
          </div>
        ) : (
          <div className="mt-8 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {featured.map((product: ProductCardProps) => (
              <ProductCard key={product.id} {...product} />
            ))}
          </div>
        )}
      </section>

      <section className="border-y border-border/50 bg-background/50 px-4 py-20 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <h2 className="text-center text-3xl font-bold tracking-tight text-foreground">Por que vender no ZeziFy?</h2>
          <div className="mt-12 grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-4">
            <Feature
              icon={<Zap className="h-6 w-6" />}
              title="Entrega instantânea"
              description="Seus clientes recebem o arquivo digital imediatamente após o pagamento."
            />
            <Feature
              icon={<Shield className="h-6 w-6" />}
              title="Pagamentos seguros"
              description="Checkout protegido com criptografia e gestão de fraudes."
            />
            <Feature
              icon={<Globe className="h-6 w-6" />}
              title="Alcance global"
              description="Venda para qualquer lugar do mundo em múltiplas moedas."
            />
            <Feature
              icon={<Headphones className="h-6 w-6" />}
              title="Suporte dedicado"
              description="Nossa equipe ajuda você e seus compradores em cada etapa."
            />
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-4xl px-4 py-20 text-center sm:px-6 lg:px-8">
        <h2 className="text-3xl font-bold tracking-tight text-foreground">Pronto para monetizar seu conhecimento?</h2>
        <p className="mx-auto mt-4 max-w-2xl text-lg text-muted-foreground">
          Junte-se a milhares de criadores que já transformam ideias em renda com ativos digitais.
        </p>
        <div className="mt-8 flex flex-col items-center justify-center gap-4 sm:flex-row">
          <Link
            to="/dashboard"
            className="inline-flex items-center justify-center gap-2 rounded-full bg-primary px-8 py-3.5 text-base font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition-all hover:bg-primary/90"
          >
            Criar minha loja
            <ArrowRight className="h-5 w-5" />
          </Link>
          <Link
            to="/explore"
            className="inline-flex items-center justify-center gap-2 rounded-full border border-input bg-background px-8 py-3.5 text-base font-semibold text-foreground transition-colors hover:bg-accent"
          >
            Explorar produtos
          </Link>
        </div>
      </section>
    </div>
  );
}

function Feature({
  icon,
  title,
  description,
}: {
  icon: React.ReactNode;
  title: string;
  description: string;
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-6 transition-colors hover:border-primary/20">
      <div className="inline-flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary">
        {icon}
      </div>
      <h3 className="mt-4 text-lg font-semibold text-foreground">{title}</h3>
      <p className="mt-2 text-sm text-muted-foreground">{description}</p>
    </div>
  );
}
