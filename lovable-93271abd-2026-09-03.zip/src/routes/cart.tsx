import { createFileRoute, Link } from "@tanstack/react-router";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Carrinho — ZeziFy" },
      { name: "description", content: "Revise os ativos digitais selecionados antes de finalizar a compra." },
      { property: "og:title", content: "Carrinho — ZeziFy" },
      { property: "og:description", content: "Revise os ativos digitais selecionados antes de finalizar a compra." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  return (
    <div className="mx-auto max-w-3xl px-4 py-20 text-center">
      <h1 className="text-3xl font-bold text-foreground">Seu carrinho está vazio</h1>
      <p className="mt-3 text-muted-foreground">
        Explore o catálogo e adicione ativos digitais ao carrinho.
      </p>
      <Link
        to="/explore"
        className="mt-8 inline-flex rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground"
      >
        Explorar catálogo
      </Link>
    </div>
  );
}
