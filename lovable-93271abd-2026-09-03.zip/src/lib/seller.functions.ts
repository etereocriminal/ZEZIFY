import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { Database } from "@/integrations/supabase/types";

type DeliveryType = Database["public"]["Enums"]["delivery_type"];
type ProductStatus = Database["public"]["Enums"]["product_status"];

export type ProductInput = {
  id?: string | undefined;
  title: string;
  short_description?: string | undefined;
  description?: string | undefined;
  price: number;
  category_id?: string | undefined;
  delivery_type: DeliveryType;
  delivery_instructions?: string | undefined;
  external_url?: string | undefined;
  file_url?: string | undefined;
  cover_url?: string | undefined;
  tags?: string[] | undefined;
  status: ProductStatus;
};

function slugify(value: string) {
  return value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

export const getSellerOverview = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;

    const [products, keys, items] = await Promise.all([
      supabase.from("products").select("id, status").eq("seller_id", userId),
      supabase.from("license_keys").select("id, status").eq("seller_id", userId),
      supabase.from("order_items").select("price_at_purchase").eq("seller_id", userId),
    ]);

    if (products.error) throw new Error(products.error.message);

    const list = products.data ?? [];
    const keyList = keys.data ?? [];
    const itemList = items.data ?? [];

    return {
      totalProducts: list.length,
      publishedProducts: list.filter((p) => p.status === "published").length,
      draftProducts: list.filter((p) => p.status === "draft").length,
      keysAvailable: keyList.filter((k) => k.status === "available").length,
      keysSold: keyList.filter((k) => k.status === "sold").length,
      salesCount: itemList.length,
      revenue: itemList.reduce((sum, i) => sum + Number(i.price_at_purchase ?? 0), 0),
    };
  });

export const listMyProducts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    const { data, error } = await supabase
      .from("products")
      .select(
        "id, slug, title, price, currency, status, delivery_type, cover_url, sales_count, created_at, categories(name)"
      )
      .eq("seller_id", userId)
      .order("created_at", { ascending: false });

    if (error) throw new Error(error.message);

    const productIds = (data ?? []).map((p) => p.id);
    const counts = new Map<string, number>();
    if (productIds.length > 0) {
      const { data: keys } = await supabase
        .from("license_keys")
        .select("product_id")
        .eq("seller_id", userId)
        .eq("status", "available")
        .in("product_id", productIds);
      for (const k of keys ?? []) {
        counts.set(k.product_id, (counts.get(k.product_id) ?? 0) + 1);
      }
    }

    return (data ?? []).map((p) => ({
      id: p.id,
      slug: p.slug,
      title: p.title,
      price: Number(p.price),
      currency: p.currency,
      status: p.status,
      delivery_type: p.delivery_type,
      cover_url: p.cover_url,
      sales_count: p.sales_count ?? 0,
      category_name: p.categories?.name ?? null,
      keys_available: counts.get(p.id) ?? 0,
    }));
  });

export const getMyProduct = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: product, error } = await supabase
      .from("products")
      .select("*")
      .eq("id", data.id)
      .eq("seller_id", userId)
      .single();

    if (error) throw new Error(error.message);
    return product;
  });

export const saveProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: ProductInput) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    if (!data.title.trim()) throw new Error("Informe um título para o ativo.");
    if (data.price < 0) throw new Error("O preço não pode ser negativo.");

    const payload = {
      title: data.title.trim(),
      short_description: data.short_description?.trim() || null,
      description: data.description?.trim() || null,
      price: data.price,
      category_id: data.category_id || null,
      delivery_type: data.delivery_type,
      delivery_instructions: data.delivery_instructions?.trim() || null,
      external_url: data.external_url?.trim() || null,
      file_url: data.file_url?.trim() || null,
      cover_url: data.cover_url?.trim() || null,
      tags: data.tags ?? [],
      status: data.status,
    };

    if (data.id) {
      const { data: updated, error } = await supabase
        .from("products")
        .update(payload)
        .eq("id", data.id)
        .eq("seller_id", userId)
        .select("id, slug")
        .single();
      if (error) throw new Error(error.message);
      return updated;
    }

    const slug = `${slugify(payload.title) || "ativo"}-${Math.random().toString(36).slice(2, 7)}`;
    const { data: created, error } = await supabase
      .from("products")
      .insert({ ...payload, slug, seller_id: userId })
      .select("id, slug")
      .single();
    if (error) throw new Error(error.message);
    return created;
  });

export const setProductStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string; status: ProductStatus }) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("products")
      .update({ status: data.status })
      .eq("id", data.id)
      .eq("seller_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("products")
      .delete()
      .eq("id", data.id)
      .eq("seller_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const listLicenseKeys = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { productId: string }) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { data: keys, error } = await supabase
      .from("license_keys")
      .select("id, key_value, status, note, created_at")
      .eq("product_id", data.productId)
      .eq("seller_id", userId)
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return keys ?? [];
  });

export const addLicenseKeys = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { productId: string; keys: string; note?: string | undefined }) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;

    const values = data.keys
      .split(/\r?\n/)
      .map((v) => v.trim())
      .filter(Boolean);

    if (values.length === 0) throw new Error("Cole ao menos uma chave, uma por linha.");

    const { data: product, error: productError } = await supabase
      .from("products")
      .select("id")
      .eq("id", data.productId)
      .eq("seller_id", userId)
      .single();
    if (productError || !product) throw new Error("Produto não encontrado.");

    const { error } = await supabase.from("license_keys").insert(
      values.map((key_value) => ({
        product_id: data.productId,
        seller_id: userId,
        key_value,
        note: data.note?.trim() || null,
      }))
    );
    if (error) throw new Error(error.message);
    return { added: values.length };
  });

export const deleteLicenseKey = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { id: string }) => input)
  .handler(async ({ data, context }) => {
    const { supabase, userId } = context;
    const { error } = await supabase
      .from("license_keys")
      .delete()
      .eq("id", data.id)
      .eq("seller_id", userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
