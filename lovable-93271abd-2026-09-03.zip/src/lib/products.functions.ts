import { createServerFn } from "@tanstack/react-start";
import { createClient } from "@supabase/supabase-js";
import type { Database } from "@/integrations/supabase/types";

function getPublicClient() {
  const url = process.env["SUPABASE_URL"]!;
  const key = process.env["SUPABASE_PUBLISHABLE_KEY"]!;
  return createClient<Database>(url, key, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

export const listCategories = createServerFn({ method: "GET" }).handler(async () => {
  const supabase = getPublicClient();
  const { data, error } = await supabase
    .from("categories")
    .select("id, slug, name, description, icon, sort_order")
    .order("sort_order", { ascending: true });

  if (error) throw new Error(error.message);
  return data ?? [];
});

export const listPublishedProducts = createServerFn({ method: "GET" })
  .inputValidator((input: { categorySlug?: string | undefined; search?: string | undefined; limit?: number | undefined; offset?: number | undefined }) => input)
  .handler(async ({ data }) => {
    const supabase = getPublicClient();

    let query = supabase
      .from("products")
      .select(
        "id, slug, title, short_description, price, currency, cover_url, rating, review_count, sales_count, categories(name), seller_id",
        { count: "exact" }
      )
      .eq("status", "published")
      .order("sales_count", { ascending: false })
      .range(data.offset ?? 0, (data.offset ?? 0) + (data.limit ?? 24) - 1);

    if (data.categorySlug) {
      const { data: category } = await supabase.from("categories").select("id").eq("slug", data.categorySlug).single();
      if (category) {
        query = query.eq("category_id", category.id);
      }
    }

    if (data.search) {
      query = query.or(`title.ilike.%${data.search}%,description.ilike.%${data.search}%`);
    }

    const { data: products, error, count } = await query;

    if (error) throw new Error(error.message);

    return {
      products:
        products?.map((p) => ({
          id: p.id,
          slug: p.slug,
          title: p.title,
          short_description: p.short_description,
          price: p.price,
          currency: p.currency,
          cover_url: p.cover_url,
          rating: p.rating,
          review_count: p.review_count,
          category_name: p.categories?.name ?? null,
          seller_display_name: null as string | null,
        })) ?? [],
      count: count ?? 0,
    };
  });

export const getProductBySlug = createServerFn({ method: "GET" })
  .inputValidator((input: { slug: string }) => input)
  .handler(async ({ data }) => {
    const supabase = getPublicClient();
    const { data: product, error } = await supabase
      .from("products")
      .select(
        "*, categories(id, slug, name)"
      )
      .eq("slug", data.slug)
      .eq("status", "published")
      .single();

    if (error) throw new Error(error.message);
    if (!product) throw new Error("Produto não encontrado");

    return {
      ...product,
      profiles: null as {
        display_name: string | null;
        avatar_url: string | null;
        bio: string | null;
        is_seller: boolean | null;
      } | null,
    };
  });

export const getFeaturedProducts = createServerFn({ method: "GET" }).handler(async () => {
  const supabase = getPublicClient();
  const { data, error } = await supabase
    .from("products")
    .select(
      "id, slug, title, short_description, price, currency, cover_url, rating, review_count, sales_count, categories(name), seller_id"
    )
    .eq("status", "published")
    .order("sales_count", { ascending: false })
    .limit(8);

  if (error) throw new Error(error.message);

  return (
    data?.map((p) => ({
      id: p.id,
      slug: p.slug,
      title: p.title,
      short_description: p.short_description,
      price: p.price,
      currency: p.currency,
      cover_url: p.cover_url,
      rating: p.rating,
      review_count: p.review_count,
      category_name: p.categories?.name ?? null,
      seller_display_name: null as string | null,
    })) ?? []
  );
});
