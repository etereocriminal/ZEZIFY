export function LogoMark({ className = "h-7 w-7" }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <defs>
        <linearGradient id="zezify-grad" x1="0" y1="0" x2="32" y2="32" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#6366f1" />
          <stop offset="1" stopColor="#a855f7" />
        </linearGradient>
      </defs>
      <rect width="32" height="32" rx="8" fill="url(#zezify-grad)" />
      <path
        d="M10 9.5h12v3.4l-7.2 9.7H22v3.4H10v-3.4l7.2-9.7H10V9.5z"
        fill="#fff"
      />
    </svg>
  );
}

export function Logo({ className = "text-xl" }: { className?: string }) {
  return (
    <span className={`flex items-center gap-2 font-bold tracking-tight text-foreground ${className}`}>
      <LogoMark className="h-7 w-7" />
      <span>ZeziFy</span>
    </span>
  );
}
