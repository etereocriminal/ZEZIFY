import { Logo } from "@/components/Logo";

export function Footer() {
  return (
    <footer className="w-full border-t border-border/50 bg-background/50 py-12">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col items-start justify-between gap-8 md:flex-row">
          <div className="max-w-sm">
            <Logo />
            <p className="mt-3 text-sm text-muted-foreground">
              O marketplace para criadores venderem cursos, ebooks, templates, SaaS e outros ativos digitais.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            <div>
              <h4 className="text-sm font-semibold text-foreground">Plataforma</h4>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                <li><a href="/explore" className="hover:text-foreground">Explorar</a></li>
                <li><a href="/pricing" className="hover:text-foreground">Preços</a></li>
                <li><a href="/_authenticated/dashboard" className="hover:text-foreground">Vender</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-foreground">Suporte</h4>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                <li><a href="/help" className="hover:text-foreground">Central de ajuda</a></li>
                <li><a href="/contact" className="hover:text-foreground">Contato</a></li>
                <li><a href="/terms" className="hover:text-foreground">Termos</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-sm font-semibold text-foreground">Social</h4>
              <ul className="mt-3 space-y-2 text-sm text-muted-foreground">
                <li><a href="https://twitter.com" target="_blank" rel="noreferrer" className="hover:text-foreground">Twitter</a></li>
                <li><a href="https://instagram.com" target="_blank" rel="noreferrer" className="hover:text-foreground">Instagram</a></li>
                <li><a href="https://youtube.com" target="_blank" rel="noreferrer" className="hover:text-foreground">YouTube</a></li>
              </ul>
            </div>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t border-border/50 pt-8 text-sm text-muted-foreground md:flex-row">
          <p>&copy; {new Date().getFullYear()} ZeziFy. Todos os direitos reservados.</p>
          <div className="flex gap-6">
            <a href="/privacy" className="hover:text-foreground">Privacidade</a>
            <a href="/terms" className="hover:text-foreground">Termos</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
