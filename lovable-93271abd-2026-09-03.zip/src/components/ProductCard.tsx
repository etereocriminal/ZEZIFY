import { Link } from "@tanstack/react-router";
import { Star } from "lucide-react";

export type ProductCardProps = {
  id: string;
  slug: string;
  title: string;
  short_description: string | null;
  price: number;
  currency: string;
  cover_url: string | null;
  rating: number | null;
  review_count: number | null;
  category_name?: string | null;
  seller_display_name?: string | null;
};

export function ProductCard({
  slug,
  title,
  short_description,
  price,
  currency,
  cover_url,
  rating,
  review_count,
  category_name,
  seller_display_name,
}: ProductCardProps) {
  const formattedPrice = new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency,
  }).format(price);

  return (
    <Link
      to="/products/$slug"
      params={{ slug }}
      className="group flex flex-col overflow-hidden rounded-2xl border border-border bg-card transition-all hover:-translate-y-1 hover:border-primary/30 hover:shadow-xl hover:shadow-primary/10"
    >
      <div className="relative aspect-[4/3] overflow-hidden bg-muted">
        {cover_url ? (
          <img
            src={cover_url}
            alt={title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            loading="lazy"
          />
        ) : (
          <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-primary/10 to-accent/10 text-muted-foreground">
            Sem imagem
          </div>
        )}
        {category_name && (
          <span className="absolute left-3 top-3 rounded-full bg-background/80 px-2.5 py-1 text-xs font-medium text-foreground backdrop-blur-sm">
            {category_name}
          </span>
        )}
      </div>

      <div className="flex flex-1 flex-col p-4">
        <h3 className="line-clamp-1 text-base font-semibold text-foreground group-hover:text-primary">
          {title}
        </h3>
        {short_description && (
          <p className="mt-1 line-clamp-2 text-sm text-muted-foreground">{short_description}</p>
        )}

        {seller_display_name && (
          <p className="mt-3 text-xs text-muted-foreground">por {seller_display_name}</p>
        )}

        <div className="mt-4 flex items-center justify-between">
          <span className="text-lg font-bold text-foreground">{formattedPrice}</span>
          <div className="flex items-center gap-1 text-xs text-muted-foreground">
            <Star className="h-3.5 w-3.5 fill-primary text-primary" />
            <span>{(rating ?? 0).toFixed(1)}</span>
            <span>({review_count ?? 0})</span>
          </div>
        </div>
      </div>
    </Link>
  );
}
